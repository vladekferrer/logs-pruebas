"""
API del dashboard TBS.

Expone 8 endpoints JSON que el frontend consume.
Correr con: uvicorn api.main:app --reload --port 8000
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy import create_engine, text
from pathlib import Path
from config import config

app = FastAPI(title="TBS Dashboard API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

engine = create_engine(config.DB_URL, echo=False)


def query(sql: str, params: dict = None) -> list:
    with engine.connect() as conn:
        result = conn.execute(text(sql), params or {})
        cols = list(result.keys())
        return [dict(zip(cols, row)) for row in result.fetchall()]


def query_one(sql: str, params: dict = None) -> dict:
    rows = query(sql, params)
    return rows[0] if rows else {}


# ============================================================
# Sirve el frontend estático
# ============================================================
FRONTEND_DIR = Path(__file__).parent.parent / "frontend"

@app.get("/")
def home():
    return FileResponse(FRONTEND_DIR / "index.html")


# ============================================================
# Endpoint 1 — North Star
# ============================================================
@app.get("/api/north-star")
def north_star():
    """KPIs del mes actual vs anterior."""
    return query_one("SELECT * FROM v_north_star")


# ============================================================
# Endpoint 2 — Tendencia mensual
# ============================================================
@app.get("/api/tendencia-mensual")
def tendencia_mensual():
    """GMV mes a mes de los últimos 12 meses."""
    return {"meses": query("SELECT * FROM v_tendencia_mensual")}


# ============================================================
# Endpoint 3 — Clientes top
# ============================================================
@app.get("/api/clientes-top")
def clientes_top(limite: int = 30):
    """Top N clientes por GMV anual con estado y tendencia."""
    return {
        "clientes": query(
            f"SELECT * FROM v_clientes_top LIMIT {min(limite, 100)}"
        )
    }


@app.get("/api/clientes-top/{id_cliente}")
def cliente_detalle(id_cliente: int):
    """Detalle de un cliente específico."""
    cliente = query_one(
        "SELECT * FROM v_clientes_top WHERE id_cliente = :id",
        {"id": id_cliente}
    )
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    # Historial mensual de este cliente
    historial = query("""
        SELECT
            strftime('%Y-%m', date_order) AS mes,
            ROUND(SUM(amount_untaxed), 0) AS gmv,
            COUNT(id) AS ordenes
        FROM raw_sale_order
        WHERE partner_id = :id
          AND state IN ('sale', 'done')
          AND company_id = 2
          AND date_order >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', date_order)
        ORDER BY mes
    """, {"id": id_cliente})

    # White space de este cliente
    white_space = query(
        "SELECT * FROM v_white_space WHERE partner_id = :id",
        {"id": id_cliente}
    )

    return {
        "cliente": cliente,
        "historial_mensual": historial,
        "white_space": white_space
    }


# ============================================================
# Endpoint 4 — Vendedores
# ============================================================
@app.get("/api/vendedores")
def vendedores():
    """Productividad de todos los vendedores."""
    return {"vendedores": query("SELECT * FROM v_vendedores")}


# ============================================================
# Endpoint 5 — Cartera aging
# ============================================================
@app.get("/api/cartera-aging")
def cartera_aging():
    """Resumen de cartera por bucket de antigüedad."""
    resumen = query("""
        SELECT
            bucket_aging,
            COUNT(*) AS facturas,
            ROUND(SUM(saldo_pendiente), 0) AS total,
            COUNT(DISTINCT partner_id) AS clientes
        FROM v_cartera_aging
        GROUP BY bucket_aging
        ORDER BY CASE bucket_aging
            WHEN '0-30 dias'  THEN 1
            WHEN '31-45 dias' THEN 2
            WHEN '46-60 dias' THEN 3
            WHEN '61-90 dias' THEN 4
            WHEN '+90 dias'   THEN 5
            ELSE 6 END
    """)

    top_deudores = query("""
        SELECT
            cliente,
            ROUND(SUM(saldo_pendiente), 0) AS total_adeudado,
            MAX(dias_vencido) AS max_dias_vencido,
            COUNT(*) AS facturas_pendientes
        FROM v_cartera_aging
        GROUP BY partner_id, cliente
        ORDER BY total_adeudado DESC
        LIMIT 10
    """)

    return {
        "resumen_aging": resumen,
        "top_deudores": top_deudores
    }


# ============================================================
# Endpoint 6 — Categorías y portafolio
# ============================================================
@app.get("/api/categorias")
def categorias():
    """Mix de categorías de producto por GMV y margen."""
    return {"categorias": query("SELECT * FROM v_categorias")}


# ============================================================
# Endpoint 7 — Alertas operativas
# ============================================================
@app.get("/api/alertas")
def alertas():
    """Alertas activas ordenadas por prioridad."""
    rojas = query(
        "SELECT * FROM v_alertas WHERE semaforo = 'rojo' LIMIT 20"
    )
    amarillas = query(
        "SELECT * FROM v_alertas WHERE semaforo = 'amarillo' LIMIT 20"
    )
    return {
        "rojas": rojas,
        "amarillas": amarillas,
        "total_rojas": len(rojas),
        "total_amarillas": len(amarillas)
    }


# ============================================================
# Endpoint 8 — White space (oportunidades de densificación)
# ============================================================
@app.get("/api/white-space")
def white_space_top():
    """Resumen de white space para los top 30 clientes."""
    oportunidades = query("""
        SELECT
            cliente,
            COUNT(*) AS categorias_faltantes,
            GROUP_CONCAT(categoria, ', ') AS que_no_compra
        FROM v_white_space
        WHERE es_white_space = 1
        GROUP BY partner_id, cliente
        HAVING categorias_faltantes >= 2
        ORDER BY categorias_faltantes DESC
        LIMIT 20
    """)
    return {"oportunidades": oportunidades}


# ============================================================
# Endpoint de salud — para verificar que el API corre
# ============================================================
@app.get("/api/salud")
def salud():
    try:
        result = query_one("SELECT COUNT(*) AS ordenes FROM raw_sale_order")
        return {
            "estado": "ok",
            "ordenes_en_db": result.get("ordenes", 0),
            "db_path": config.DB_PATH
        }
    except Exception as e:
        return {"estado": "error", "mensaje": str(e)}
